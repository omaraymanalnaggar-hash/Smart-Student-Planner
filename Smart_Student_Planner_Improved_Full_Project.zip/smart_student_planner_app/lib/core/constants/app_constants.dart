import 'package:flutter/material.dart';

class AppConstants {
  static const Color primaryColor = Color(0xFF4F46E5);
  static const Color accentColor = Color(0xFF06B6D4);
  static const Color successColor = Color(0xFF22C55E);
  static const Color warningColor = Color(0xFFF59E0B);
  static const Color dangerColor = Color(0xFFEF4444);
  static const Color backgroundColor = Color(0xFFF8FAFC);

  static const String appName = 'Smart Student Planner';
}
