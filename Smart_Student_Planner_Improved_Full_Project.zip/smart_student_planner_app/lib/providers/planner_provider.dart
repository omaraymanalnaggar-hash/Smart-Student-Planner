import 'package:flutter/material.dart';
import '../data/models/task_model.dart';
import '../data/models/exam_model.dart';
import '../data/models/note_model.dart';
import '../data/repositories/task_repository.dart';
import '../data/repositories/exam_repository.dart';
import '../data/repositories/note_repository.dart';

class PlannerProvider extends ChangeNotifier {
  final TaskRepository _taskRepository = TaskRepository();
  final ExamRepository _examRepository = ExamRepository();
  final NoteRepository _noteRepository = NoteRepository();

  List<TaskModel> tasks = [];
  List<ExamModel> exams = [];
  List<NoteModel> notes = [];
  bool isLoading = false;
  bool _seedChecked = false;

  int get completedTasks => tasks.where((t) => t.isCompleted == 1).length;
  int get pendingTasks => tasks.where((t) => t.isCompleted == 0).length;
  int get highPriorityTasks => tasks.where((t) => t.priority == 3 && t.isCompleted == 0).length;
  double get completionRate => tasks.isEmpty ? 0 : completedTasks / tasks.length;

  Future<void> loadAll() async {
    isLoading = true;
    notifyListeners();
    tasks = await _taskRepository.getTasks();
    exams = await _examRepository.getExams();
    notes = await _noteRepository.getNotes();
    if (!_seedChecked && tasks.isEmpty && exams.isEmpty && notes.isEmpty) {
      _seedChecked = true;
      await seedDemoData();
      tasks = await _taskRepository.getTasks();
      exams = await _examRepository.getExams();
      notes = await _noteRepository.getNotes();
    }
    isLoading = false;
    notifyListeners();
  }

  Future<void> seedDemoData() async {
    final demoTasks = [
      TaskModel(title: 'Finish Flutter Project Report', description: 'Add screenshots, architecture explanation, SQLite DAO Repository details, and export PDF.', course: 'CEN306', dueDate: '2026-06-14', priority: 3, isCompleted: 0),
      TaskModel(title: 'Prepare 3-minute Demo Script', description: 'Practice explaining dashboard, tasks, exams, notes, SQLite, DAO, Repository, and Provider.', course: 'Mobile App Design', dueDate: '2026-06-15', priority: 3, isCompleted: 0),
      TaskModel(title: 'Study General Chemistry Chapter 5-9', description: 'Review end-of-chapter questions and PowerPoint slide questions before the final exam.', course: 'General Chemistry', dueDate: '2026-06-16', priority: 2, isCompleted: 0),
      TaskModel(title: 'Review Programming 2 Notes', description: 'Revise JavaFX, OOP classes, event handling, and project explanation.', course: 'Programming II', dueDate: '2026-06-18', priority: 2, isCompleted: 1),
      TaskModel(title: 'Upload Final Submission Package', description: 'Submit the project zip, report PDF, and demo video link to ALMS.', course: 'CEN306', dueDate: '2026-06-19', priority: 3, isCompleted: 0),
      TaskModel(title: 'Bring Laptop Charger', description: 'Prepare laptop, charger, screenshots, and backup APK before project demo.', course: 'Demo Day', dueDate: '2026-06-20', priority: 1, isCompleted: 0),
    ];
    for (final task in demoTasks) { await _taskRepository.addTask(task); }

    final demoExams = [
      ExamModel(subject: 'General Chemistry Final', examDate: '2026-06-17', location: 'Main Campus - B203', notes: 'Chapters 5 to 9, MCQ and written questions.'),
      ExamModel(subject: 'Programming II Final', examDate: '2026-06-18', location: 'Computer Lab 2', notes: 'Focus on OOP, JavaFX UI, and file handling.'),
      ExamModel(subject: 'CEN306 Project Demo', examDate: '2026-06-20', location: 'Mobile App Lab', notes: 'Show Flutter app, SQLite storage, DAO, Repository, and report PDF.'),
    ];
    for (final exam in demoExams) { await _examRepository.addExam(exam); }

    final demoNotes = [
      NoteModel(title: 'Demo explanation', content: 'Start with the problem: students forget deadlines. Then show dashboard, task CRUD, exams, notes, and the technical layers.', createdAt: '2026-06-10'),
      NoteModel(title: 'Architecture keywords', content: 'Presentation Layer, Provider State Management, Repository, DAO, SQLite Database, Model classes.', createdAt: '2026-06-10'),
      NoteModel(title: 'Report checklist', content: 'No source code in report. Add screenshots, technical design, challenges, testing, and future improvements.', createdAt: '2026-06-10'),
      NoteModel(title: 'Future features', content: 'Notifications, cloud sync, login, GPA calculator, and calendar view can be mentioned as future work.', createdAt: '2026-06-10'),
    ];
    for (final note in demoNotes) { await _noteRepository.addNote(note); }
  }

  Future<void> addTask(TaskModel task) async { await _taskRepository.addTask(task); await loadAll(); }
  Future<void> updateTask(TaskModel task) async { await _taskRepository.updateTask(task); await loadAll(); }
  Future<void> deleteTask(int id) async { await _taskRepository.deleteTask(id); await loadAll(); }
  Future<void> toggleTask(TaskModel task) async { await updateTask(task.copyWith(isCompleted: task.isCompleted == 1 ? 0 : 1)); }
  Future<void> searchTasks(String keyword) async { tasks = keyword.isEmpty ? await _taskRepository.getTasks() : await _taskRepository.searchTasks(keyword); notifyListeners(); }
  Future<void> addExam(ExamModel exam) async { await _examRepository.addExam(exam); await loadAll(); }
  Future<void> deleteExam(int id) async { await _examRepository.deleteExam(id); await loadAll(); }
  Future<void> addNote(NoteModel note) async { await _noteRepository.addNote(note); await loadAll(); }
  Future<void> deleteNote(int id) async { await _noteRepository.deleteNote(id); await loadAll(); }
}
