import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/note_model.dart';

class NoteDao {
  Future<Database> get _db async => AppDatabase.instance.database;
  Future<int> insertNote(NoteModel note) async => (await _db).insert('notes', note.toMap());
  Future<List<NoteModel>> getAllNotes() async {
    final result = await (await _db).query('notes', orderBy: 'id DESC');
    return result.map((e) => NoteModel.fromMap(e)).toList();
  }
  Future<int> deleteNote(int id) async => (await _db).delete('notes', where: 'id = ?', whereArgs: [id]);
}
