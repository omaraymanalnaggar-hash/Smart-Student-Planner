import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/exam_model.dart';

class ExamDao {
  Future<Database> get _db async => AppDatabase.instance.database;
  Future<int> insertExam(ExamModel exam) async => (await _db).insert('exams', exam.toMap());
  Future<List<ExamModel>> getAllExams() async {
    final result = await (await _db).query('exams', orderBy: 'examDate ASC');
    return result.map((e) => ExamModel.fromMap(e)).toList();
  }
  Future<int> deleteExam(int id) async => (await _db).delete('exams', where: 'id = ?', whereArgs: [id]);
}
