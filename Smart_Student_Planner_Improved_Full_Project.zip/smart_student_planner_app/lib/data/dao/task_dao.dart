import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/task_model.dart';

class TaskDao {
  Future<Database> get _db async => AppDatabase.instance.database;

  Future<int> insertTask(TaskModel task) async => (await _db).insert('tasks', task.toMap());
  Future<List<TaskModel>> getAllTasks() async {
    final result = await (await _db).query('tasks', orderBy: 'dueDate ASC');
    return result.map((e) => TaskModel.fromMap(e)).toList();
  }
  Future<int> updateTask(TaskModel task) async => (await _db).update('tasks', task.toMap(), where: 'id = ?', whereArgs: [task.id]);
  Future<int> deleteTask(int id) async => (await _db).delete('tasks', where: 'id = ?', whereArgs: [id]);
  Future<List<TaskModel>> searchTasks(String keyword) async {
    final result = await (await _db).query('tasks', where: 'title LIKE ? OR course LIKE ?', whereArgs: ['%$keyword%', '%$keyword%'], orderBy: 'dueDate ASC');
    return result.map((e) => TaskModel.fromMap(e)).toList();
  }
}
