import '../dao/exam_dao.dart';
import '../models/exam_model.dart';

class ExamRepository {
  final ExamDao _dao = ExamDao();
  Future<int> addExam(ExamModel exam) => _dao.insertExam(exam);
  Future<List<ExamModel>> getExams() => _dao.getAllExams();
  Future<int> deleteExam(int id) => _dao.deleteExam(id);
}
