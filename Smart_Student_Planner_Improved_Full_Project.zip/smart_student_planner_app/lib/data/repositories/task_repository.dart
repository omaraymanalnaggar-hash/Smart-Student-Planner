import '../dao/task_dao.dart';
import '../models/task_model.dart';

class TaskRepository {
  final TaskDao _dao = TaskDao();
  Future<int> addTask(TaskModel task) => _dao.insertTask(task);
  Future<List<TaskModel>> getTasks() => _dao.getAllTasks();
  Future<int> updateTask(TaskModel task) => _dao.updateTask(task);
  Future<int> deleteTask(int id) => _dao.deleteTask(id);
  Future<List<TaskModel>> searchTasks(String keyword) => _dao.searchTasks(keyword);
}
