import '../dao/note_dao.dart';
import '../models/note_model.dart';

class NoteRepository {
  final NoteDao _dao = NoteDao();
  Future<int> addNote(NoteModel note) => _dao.insertNote(note);
  Future<List<NoteModel>> getNotes() => _dao.getAllNotes();
  Future<int> deleteNote(int id) => _dao.deleteNote(id);
}
