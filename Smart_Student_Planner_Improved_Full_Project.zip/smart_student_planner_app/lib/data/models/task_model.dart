class TaskModel {
  final int? id;
  final String title;
  final String description;
  final String course;
  final String dueDate;
  final int priority;
  final int isCompleted;

  TaskModel({
    this.id,
    required this.title,
    required this.description,
    required this.course,
    required this.dueDate,
    required this.priority,
    required this.isCompleted,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'description': description,
        'course': course,
        'dueDate': dueDate,
        'priority': priority,
        'isCompleted': isCompleted,
      };

  factory TaskModel.fromMap(Map<String, dynamic> map) => TaskModel(
        id: map['id'],
        title: map['title'],
        description: map['description'],
        course: map['course'],
        dueDate: map['dueDate'],
        priority: map['priority'],
        isCompleted: map['isCompleted'],
      );

  TaskModel copyWith({int? id, String? title, String? description, String? course, String? dueDate, int? priority, int? isCompleted}) {
    return TaskModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      course: course ?? this.course,
      dueDate: dueDate ?? this.dueDate,
      priority: priority ?? this.priority,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }
}
