class NoteModel {
  final int? id;
  final String title;
  final String content;
  final String createdAt;

  NoteModel({this.id, required this.title, required this.content, required this.createdAt});

  Map<String, dynamic> toMap() => {'id': id, 'title': title, 'content': content, 'createdAt': createdAt};

  factory NoteModel.fromMap(Map<String, dynamic> map) => NoteModel(
        id: map['id'],
        title: map['title'],
        content: map['content'],
        createdAt: map['createdAt'],
      );
}
