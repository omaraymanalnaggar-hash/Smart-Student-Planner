class ExamModel {
  final int? id;
  final String subject;
  final String examDate;
  final String location;
  final String notes;

  ExamModel({this.id, required this.subject, required this.examDate, required this.location, required this.notes});

  Map<String, dynamic> toMap() => {'id': id, 'subject': subject, 'examDate': examDate, 'location': location, 'notes': notes};

  factory ExamModel.fromMap(Map<String, dynamic> map) => ExamModel(
        id: map['id'],
        subject: map['subject'],
        examDate: map['examDate'],
        location: map['location'],
        notes: map['notes'],
      );
}
