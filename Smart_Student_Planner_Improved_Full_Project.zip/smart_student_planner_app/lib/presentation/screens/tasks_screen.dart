import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/planner_provider.dart';
import 'add_task_screen.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});
  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  final searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PlannerProvider>();
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Tasks & Assignments', style: TextStyle(fontWeight: FontWeight.bold))),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddTaskScreen())),
          icon: const Icon(Icons.add),
          label: const Text('New Task'),
        ),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          TextField(
            controller: searchController,
            onChanged: provider.searchTasks,
            decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Search by title or course', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
          ),
          const SizedBox(height: 14),
          if (provider.tasks.isEmpty)
            const Padding(padding: EdgeInsets.only(top: 80), child: Center(child: Text('No tasks found. Tap New Task to add one.')))
          else
            ...provider.tasks.map((task) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: Checkbox(value: task.isCompleted == 1, onChanged: (_) => provider.toggleTask(task)),
                title: Text(task.title, style: TextStyle(fontWeight: FontWeight.bold, decoration: task.isCompleted == 1 ? TextDecoration.lineThrough : null)),
                subtitle: Text('${task.course}\n${task.description}\nDue: ${task.dueDate}'),
                isThreeLine: true,
                trailing: PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'edit') Navigator.push(context, MaterialPageRoute(builder: (_) => AddTaskScreen(task: task)));
                    if (value == 'delete' && task.id != null) provider.deleteTask(task.id!);
                  },
                  itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'delete', child: Text('Delete'))],
                ),
              ),
            )),
          const SizedBox(height: 80),
        ]),
      ),
    );
  }
}
