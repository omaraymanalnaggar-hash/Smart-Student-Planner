import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/models/task_model.dart';
import '../../providers/planner_provider.dart';

class AddTaskScreen extends StatefulWidget {
  final TaskModel? task;
  const AddTaskScreen({super.key, this.task});
  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final formKey = GlobalKey<FormState>();
  late TextEditingController title;
  late TextEditingController description;
  late TextEditingController course;
  late TextEditingController dueDate;
  int priority = 2;

  @override
  void initState() {
    super.initState();
    title = TextEditingController(text: widget.task?.title ?? '');
    description = TextEditingController(text: widget.task?.description ?? '');
    course = TextEditingController(text: widget.task?.course ?? '');
    dueDate = TextEditingController(text: widget.task?.dueDate ?? '');
    priority = widget.task?.priority ?? 2;
  }

  Future<void> pickDate() async {
    final picked = await showDatePicker(context: context, firstDate: DateTime.now().subtract(const Duration(days: 1)), lastDate: DateTime(2035), initialDate: DateTime.now());
    if (picked != null) dueDate.text = '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.task == null ? 'Add Task' : 'Edit Task')),
      body: Form(
        key: formKey,
        child: ListView(padding: const EdgeInsets.all(18), children: [
          TextFormField(controller: title, decoration: const InputDecoration(labelText: 'Task title', border: OutlineInputBorder()), validator: (v) => v == null || v.trim().isEmpty ? 'Title is required' : null),
          const SizedBox(height: 12),
          TextFormField(controller: course, decoration: const InputDecoration(labelText: 'Course', border: OutlineInputBorder()), validator: (v) => v == null || v.trim().isEmpty ? 'Course is required' : null),
          const SizedBox(height: 12),
          TextFormField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'Description', border: OutlineInputBorder()), validator: (v) => v == null || v.trim().isEmpty ? 'Description is required' : null),
          const SizedBox(height: 12),
          TextFormField(controller: dueDate, readOnly: true, onTap: pickDate, decoration: const InputDecoration(labelText: 'Due date', border: OutlineInputBorder(), suffixIcon: Icon(Icons.calendar_today)), validator: (v) => v == null || v.trim().isEmpty ? 'Due date is required' : null),
          const SizedBox(height: 16),
          DropdownButtonFormField<int>(
            value: priority,
            decoration: const InputDecoration(labelText: 'Priority', border: OutlineInputBorder()),
            items: const [DropdownMenuItem(value: 1, child: Text('Low')), DropdownMenuItem(value: 2, child: Text('Medium')), DropdownMenuItem(value: 3, child: Text('High'))],
            onChanged: (v) => setState(() => priority = v ?? 2),
          ),
          const SizedBox(height: 22),
          FilledButton.icon(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              final task = TaskModel(id: widget.task?.id, title: title.text, description: description.text, course: course.text, dueDate: dueDate.text, priority: priority, isCompleted: widget.task?.isCompleted ?? 0);
              if (widget.task == null) { await context.read<PlannerProvider>().addTask(task); } else { await context.read<PlannerProvider>().updateTask(task); }
              if (context.mounted) Navigator.pop(context);
            },
            icon: const Icon(Icons.save), label: Text(widget.task == null ? 'Save Task' : 'Update Task'),
          ),
        ]),
      ),
    );
  }
}
