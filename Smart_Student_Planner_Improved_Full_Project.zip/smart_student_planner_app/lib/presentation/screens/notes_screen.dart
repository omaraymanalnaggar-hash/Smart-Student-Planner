import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/models/note_model.dart';
import '../../providers/planner_provider.dart';

class NotesScreen extends StatefulWidget { const NotesScreen({super.key}); @override State<NotesScreen> createState() => _NotesScreenState(); }
class _NotesScreenState extends State<NotesScreen> {
  final title = TextEditingController(); final content = TextEditingController();
  void showAddNote() { showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => Padding(padding: EdgeInsets.only(left: 18, right: 18, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 18), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Text('Quick Study Note', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
    TextField(controller: title, decoration: const InputDecoration(labelText: 'Title', border: OutlineInputBorder())), const SizedBox(height: 10),
    TextField(controller: content, maxLines: 4, decoration: const InputDecoration(labelText: 'Content', border: OutlineInputBorder())), const SizedBox(height: 14),
    FilledButton.icon(onPressed: () async { if (title.text.trim().isEmpty || content.text.trim().isEmpty) return; await context.read<PlannerProvider>().addNote(NoteModel(title: title.text, content: content.text, createdAt: DateTime.now().toIso8601String().substring(0, 10))); title.clear(); content.clear(); if (mounted) Navigator.pop(context); }, icon: const Icon(Icons.save), label: const Text('Save Note'))
  ]))); }
  @override Widget build(BuildContext context) { final p = context.watch<PlannerProvider>(); return SafeArea(child: Scaffold(appBar: AppBar(title: const Text('Study Notes', style: TextStyle(fontWeight: FontWeight.bold))), floatingActionButton: FloatingActionButton(onPressed: showAddNote, child: const Icon(Icons.add)), body: GridView.builder(padding: const EdgeInsets.all(16), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12), itemCount: p.notes.length, itemBuilder: (_, i) { final note = p.notes[i]; return Card(child: InkWell(borderRadius: BorderRadius.circular(12), onLongPress: () { if (note.id != null) p.deleteNote(note.id!); }, child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(note.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 8), Expanded(child: Text(note.content, overflow: TextOverflow.fade)), Text(note.createdAt, style: TextStyle(color: Colors.grey.shade600, fontSize: 12))])))); }))); }
}
