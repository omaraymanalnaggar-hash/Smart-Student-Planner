import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('Settings', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 18),
        Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: const Row(children: [CircleAvatar(radius: 28, backgroundColor: AppConstants.primaryColor, child: Icon(Icons.person, color: Colors.white)), SizedBox(width: 14), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Omar Ayman', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), Text('Computer Engineering Student')])])),
        const SizedBox(height: 14),
        const Card(child: ListTile(leading: Icon(Icons.storage), title: Text('Local Storage'), subtitle: Text('All data is saved locally using SQLite.'))),
        const Card(child: ListTile(leading: Icon(Icons.layers), title: Text('Layered Architecture'), subtitle: Text('UI, Provider logic, Repository, DAO, and SQLite layers.'))),
        const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('About'), subtitle: Text('CEN306 Final Flutter Project - Smart Student Planner App.'))),
      ]),
    );
  }
}
