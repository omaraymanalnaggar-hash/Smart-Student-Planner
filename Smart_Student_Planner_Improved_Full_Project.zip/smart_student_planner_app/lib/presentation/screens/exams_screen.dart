import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/models/exam_model.dart';
import '../../providers/planner_provider.dart';

class ExamsScreen extends StatefulWidget { const ExamsScreen({super.key}); @override State<ExamsScreen> createState() => _ExamsScreenState(); }
class _ExamsScreenState extends State<ExamsScreen> {
  final subject = TextEditingController(); final date = TextEditingController(); final location = TextEditingController(); final notes = TextEditingController();
  Future<void> pickDate() async { final picked = await showDatePicker(context: context, firstDate: DateTime.now(), lastDate: DateTime(2035), initialDate: DateTime.now()); if (picked != null) date.text = '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}'; }
  void showAddDialog() { showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => Padding(padding: EdgeInsets.only(left: 18, right: 18, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 18), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Text('Add Exam', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 14),
    TextField(controller: subject, decoration: const InputDecoration(labelText: 'Subject', border: OutlineInputBorder())), const SizedBox(height: 10),
    TextField(controller: date, readOnly: true, onTap: pickDate, decoration: const InputDecoration(labelText: 'Exam date', suffixIcon: Icon(Icons.date_range), border: OutlineInputBorder())), const SizedBox(height: 10),
    TextField(controller: location, decoration: const InputDecoration(labelText: 'Location', border: OutlineInputBorder())), const SizedBox(height: 10),
    TextField(controller: notes, decoration: const InputDecoration(labelText: 'Notes', border: OutlineInputBorder())), const SizedBox(height: 14),
    FilledButton(onPressed: () async { if (subject.text.trim().isEmpty || date.text.trim().isEmpty) return; await context.read<PlannerProvider>().addExam(ExamModel(subject: subject.text, examDate: date.text, location: location.text, notes: notes.text)); subject.clear(); date.clear(); location.clear(); notes.clear(); if (mounted) Navigator.pop(context); }, child: const Text('Save Exam'))
  ]))); }
  @override Widget build(BuildContext context) { final p = context.watch<PlannerProvider>(); return SafeArea(child: Scaffold(appBar: AppBar(title: const Text('Exams Schedule', style: TextStyle(fontWeight: FontWeight.bold))), floatingActionButton: FloatingActionButton(onPressed: showAddDialog, child: const Icon(Icons.add)), body: ListView(padding: const EdgeInsets.all(16), children: [
    if (p.exams.isEmpty) const Padding(padding: EdgeInsets.only(top: 80), child: Center(child: Text('No exams added yet.')))
    else ...p.exams.map((e) => Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.school)), title: Text(e.subject, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${e.examDate} • ${e.location}\n${e.notes}'), isThreeLine: true, trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () { if (e.id != null) p.deleteExam(e.id!); }))))
  ]))); }
}
