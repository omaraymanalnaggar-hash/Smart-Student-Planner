import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/planner_provider.dart';
import '../widgets/stat_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  Color priorityColor(int priority) {
    if (priority == 3) return AppConstants.dangerColor;
    if (priority == 2) return AppConstants.warningColor;
    return AppConstants.successColor;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<PlannerProvider>(builder: (context, provider, _) {
      return SafeArea(
        child: RefreshIndicator(
          onRefresh: provider.loadAll,
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF4338CA), Color(0xFF06B6D4)],
                  ),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [BoxShadow(color: AppConstants.primaryColor.withOpacity(.22), blurRadius: 24, offset: const Offset(0, 12))],
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(18)), child: const Icon(Icons.auto_awesome, color: Colors.white, size: 30)),
                    const Spacer(),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(99)), child: const Text('CEN306 Project', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
                  ]),
                  const SizedBox(height: 18),
                  const Text('Hi Omar 👋', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('Your semester is organized. Keep tasks, exams, and study notes in one smart offline planner.', style: TextStyle(color: Colors.white70, height: 1.35, fontSize: 15)),
                  const SizedBox(height: 20),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: LinearProgressIndicator(value: provider.completionRate, minHeight: 12, backgroundColor: Colors.white24, color: Colors.white),
                  ),
                  const SizedBox(height: 8),
                  Text('${(provider.completionRate * 100).round()}% of tasks completed', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                ]),
              ),
              const SizedBox(height: 20),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 14,
                mainAxisSpacing: 14,
                childAspectRatio: 1.05,
                children: [
                  StatCard(title: 'Pending Tasks', value: '${provider.pendingTasks}', icon: Icons.pending_actions, color: AppConstants.warningColor),
                  StatCard(title: 'Completed', value: '${provider.completedTasks}', icon: Icons.verified, color: AppConstants.successColor),
                  StatCard(title: 'Upcoming Exams', value: '${provider.exams.length}', icon: Icons.school, color: AppConstants.primaryColor),
                  StatCard(title: 'High Priority', value: '${provider.highPriorityTasks}', icon: Icons.priority_high, color: AppConstants.dangerColor),
                ],
              ),
              const SizedBox(height: 24),
              Row(children: const [
                Text('Today Focus', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                Spacer(),
                Icon(Icons.bolt, color: AppConstants.warningColor),
              ]),
              const SizedBox(height: 10),
              ...provider.tasks.take(4).map((task) => Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: priorityColor(task.priority).withOpacity(.18))),
                    child: Row(children: [
                      Container(width: 6, height: 58, decoration: BoxDecoration(color: priorityColor(task.priority), borderRadius: BorderRadius.circular(99))),
                      const SizedBox(width: 14),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(task.title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, decoration: task.isCompleted == 1 ? TextDecoration.lineThrough : null)),
                        const SizedBox(height: 4),
                        Text('${task.course} • Due: ${task.dueDate}', style: TextStyle(color: Colors.grey.shade600)),
                      ])),
                      Icon(task.isCompleted == 1 ? Icons.check_circle : Icons.circle_outlined, color: task.isCompleted == 1 ? AppConstants.successColor : priorityColor(task.priority)),
                    ]),
                  )),
              const SizedBox(height: 16),
              const Text('Next Exam', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              if (provider.exams.isNotEmpty)
                Card(child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
                  const CircleAvatar(radius: 28, backgroundColor: Color(0xFFE0E7FF), child: Icon(Icons.school, color: AppConstants.primaryColor)),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(provider.exams.first.subject, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    Text('${provider.exams.first.examDate} • ${provider.exams.first.location}', style: TextStyle(color: Colors.grey.shade600)),
                  ])),
                ]))),
              const SizedBox(height: 80),
            ],
          ),
        ),
      );
    });
  }
}
