# Smart Student Planner App

CEN306 Flutter final project.

## How to run
```bash
flutter pub get
flutter run
```

The application uses Provider for state management and SQLite through sqflite for local persistence.
